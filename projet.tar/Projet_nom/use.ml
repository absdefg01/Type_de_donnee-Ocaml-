#load "lang.cmo" ;;
#load "parser.cmo" ;;
#load "lexer.cmo" ;;
#load "interf.cmo" ;;
#load "subst.cmo" ;;
#load "unif.cmo" ;;
#load "rewriting.cmo" ;;

