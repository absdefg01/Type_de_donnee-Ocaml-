(* TODO: Unification *)

open Lang;;
open Subst;;

exception UnifError of string 

let rec unif = function 
  | p -> raise (UnifError("unif undefined"))

let unif_option t1 t2 = 
  try Some (unif ([(t1, t2)], []))
  with UnifError(ue) -> None
