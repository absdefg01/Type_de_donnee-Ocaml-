(* TODO: Rewriting *)

open Lang;;
open Subst;;
open Unif;;
open Interf;;


(* simplify a term until no more rewrite step succeeds *)
let rec simp rls trspec t = t


(* Different rewrite strategies *)


let leftmost_outermost l r t (lrew, lch, ln) (rrew, rch, rn) (trew, tch, tn) =
  if tch
  then (trew, tch, tn)
  else if lch
  then (Appl(lrew, r), lch, ln)
  else (Appl(l, rrew), rch, rn)


let parse_and_simp infile = 
  match parse infile with
    Rewr (rls, trspec, sn, t) -> 
      print_term (simp rls trspec t)
;;

(* map strategy name to strategy *)
let map_strat_name = function
  | "left_outer" -> Eager leftmost_outermost
  | n -> failwith ("strategy " ^ n ^ " not implemented.")


(* TODO: the same function using strategies, see section 4.3.3
let parse_and_simp infile = 
  match parse infile with
    Rewr (rls, trspec, sn, t) -> 
      print_term (simp rls trspec (map_strat_name sn) t)
;;

*)
