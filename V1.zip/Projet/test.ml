(*Test*)
open Lang;;

(*Exercice 11*)

(*fonctions auxiliaires*)
let rec verif = function
  |Const c -> if c = "zero" then 0 else failwith "erreur"
  |Var v  -> failwith "impossible d'aditionnner une variable"
  |Appl(a,b)-> let res = verif b in
	       if res = 0 then 1 else 1 + verif b
;;

(*
(*addition*)
let addition t1 t2 = 
  term_of_nat (verif t1 +  verif t2);;


(*soustraction*)
let soustraction t1 t2 = 
  if (verif t1>=verif t2) then
    verif t1 - verif t2
  else
    failwith "erreur"
  ;;

(*multiplication*)
let multiplication t1 t2 = 
  term_of_nat ((verif t1) * (verif t2));;
*)

type nat = Z|S of nat;;
let rec add m n =
  match n with
    |Z->Z
    |S(n')->S(add m n');;


let rec soustraction m n = 
  match n with
    |Z->m
    |S(n')-> match m with
	|Z->Z
	|S(m')->S(soustraction m' n')
;;

let rec multiplication m n=
  match n with
    |Z->Z
    |S(n')->add m (multiplication m n')
;;
 
(*Exercice 12*)
(*0 : false, 1 : true*)
let strictement_inf t1 t2 = 
  if soustraction t1 t2 > 0 then 1 else 0;;

let egal t1 t2 = 
  if soustraction t1 t2 = 0 then 1 else 0;;


(*Exercice 13*)
(*fonction n�gation*)
let negation b = 
  match b with
    |true->false
    |false->true
;;

(*fonction et*)
let et (b1,b2) = 
  match (b1,b2) with
    |(true,true)->true
    |(_,_)->false
;;

(*fonction ou*)
let ou (b1,b2) = 
  match (b1,b2) with
    |(false,false)->false
    |(_,_)->true
;;

(*Exercice 14*)
let rec div_eucli t1 t2 = 
  if (strictement_inf t1 t2) = 1 then 
    let res = (soustraction t1 t2) in
    if res>= (verif t2) then
      div_eucli (term_of_nat res) t2
    else res
  else 
  failwith "erreur"  
;;

(*Exercice 15*)
(*constructeur nil : liste vide, constructeur const : non vide*)
type list = Nil | Const of int * list;;
let rec list l = 
  match l with
    |[]->Nil
    |(e::es)->Const(e, list es)
;;

(*Pour tester : *)
let l = [1;2;3];;
list l;;

(*Exercice 16*)
(*fonction auxiliaire*)
let rec insert elem = function
  | [] -> [elem]
  | x :: l -> if elem < x then elem :: x :: l else x :: insert elem l;;
insert 1 [];;
