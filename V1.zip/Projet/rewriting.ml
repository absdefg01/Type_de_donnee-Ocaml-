(* Carry out rewriting *)

open Lang;;
open Subst;;
open Unif;;
open Interf;;

(* try_rewrite returns the rewritten term, and:
   - true if there is a change in the term
   - false if there is no change (even if rule was applicable without change)
*)

let try_rewrite l r t = 
  match unif_option t l with
  | None -> (t, false)
  | Some sb -> 
    let trew = apply_subst r sb in (trew, trew != t)

(* try to rewrite with rule list rls in term t,
   selecting the first applicable rule.
   Returns:
   the rewritten term, 
   true/false indicating change,
   the name of the applied rule (or empty string)
*)

let rec try_rewrite_rule_list rls t =
  match rls with
  | [] -> (t, false, "")
  | Rl(n, l, r) :: rls' -> 
    let (trew, tch) = try_rewrite l r t in
    if tch 
    then (trew, tch, n)
    else try_rewrite_rule_list rls' t;;

(*fonction qui prend comme arguments une liste de r�gles et un terme et effctue une r��criture dans le terme et renvoie un triplet du type rewr_result*)

let rec rewrite_in_term rls t = 
  let (trew,tch,n) = try_rewrite_rule_list rls t in
  if tch then (trew,true,n)
  else 
    match trew with
      |Const c ->(trew, false, "")
      |Var v ->failwith "impossible de r��crire une variable"
      |Appl(a,b)->let (x,y,z)=try_rewrite_rule_list rls a in
		  if y then (x,y,z)
		  else 
		    let(m,n,p)=try_rewrite_rule_list rls b in
		    if n then (m,n,p)
		    else failwith "deja le plus simple, impossible de continuer a reecrire"		   	        
;;
	
(*Pour tester : 
let rls = Rl("",a,b);;
let t = 
  Appl(
  Const a
    Appl(
      Const a,Const b
        )
  );;
rewrite_in_term rls t;;
*)
  
(*  
(*faire la simplification pour le terme*)
let rec simp rls tr t = 
  let (trew,tch,n) = rewrite_in_term rls t in
  (*si le terme peut �tre r��crit, on fait l'appel r�cursif pour le r��crire jusqu'a le terme est le plus simple*)
  if tch then 
    simp rls tr trew    
  else
    (*le terme ne peut pas �tre r��crit dans n'importe quelle position*)
    t
;;
*)


(*Pour tester : 
let rls = Rl("",a,b)
let t = 
   Appl(
  Const a
    Appl(
      Const a,Const b
        )
  );;
let tr = TraceSome("aa","bb");
*)


(*Exo 9*)
(*
let print_trace_step trace nom terme = 
  trace =  terme^"R�gle"^nom;
  print_string trace;;
*)

let print_trace_step trace nomR terme = 
	print_string ("--"^nomR^"-->\n"^(print_term terme));
  print_newline()
;;


let rec simp rls tr t = 
  let (trew,tch,n) = rewrite_in_term rls t in
  if tch then
	begin
		print_trace_step tr n trew;
		simp rls tr trew;
	end
  else
    t
;;
